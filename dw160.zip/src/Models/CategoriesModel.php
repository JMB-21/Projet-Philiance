<?php 

namespace App\Models;

use PDO;
use App\Models\Model;

class CategoriesModel extends Model {

    protected $table = 'categories';

}