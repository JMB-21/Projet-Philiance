<?php

Echo "vous etes sur la page d'accueil Connectez vous !";

?>